import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Shield, 
  Key, 
  Lock, 
  Unlock, 
  Cpu, 
  Zap, 
  Eye, 
  EyeOff, 
  Download, 
  Upload, 
  Copy, 
  Check, 
  Settings, 
  BarChart3, 
  Users, 
  Globe, 
  Menu, 
  X,
  ChevronDown,
  Play,
  Pause,
  RotateCcw,
  FileText,
  Image as ImageIcon,
  Video,
  Music
} from 'lucide-react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Input } from './components/ui/input';
import { Textarea } from './components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Badge } from './components/ui/badge';
import { Progress } from './components/ui/progress';
import { Switch } from './components/ui/switch';
import { Slider } from './components/ui/slider';
import './App.css';

// Matrix Rain Component
const MatrixRain = () => {
  const [drops, setDrops] = useState([]);

  useEffect(() => {
    const characters = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
    const newDrops = [];
    
    for (let i = 0; i < 50; i++) {
      newDrops.push({
        id: i,
        x: Math.random() * 100,
        delay: Math.random() * 5,
        chars: Array.from({ length: 20 }, () => 
          characters[Math.floor(Math.random() * characters.length)]
        )
      });
    }
    
    setDrops(newDrops);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {drops.map((drop) => (
        <motion.div
          key={drop.id}
          className="absolute text-green-500 text-sm font-mono opacity-30"
          style={{ left: `${drop.x}%` }}
          initial={{ y: -100 }}
          animate={{ y: '100vh' }}
          transition={{
            duration: 8,
            delay: drop.delay,
            repeat: Infinity,
            ease: 'linear'
          }}
        >
          {drop.chars.map((char, index) => (
            <div key={index} className="leading-4">
              {char}
            </div>
          ))}
        </motion.div>
      ))}
    </div>
  );
};

// Floating Particles Component
const FloatingParticles = () => {
  const particles = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 4 + 1,
    duration: Math.random() * 20 + 10
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute bg-green-500 rounded-full opacity-20"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: `${particle.size}px`,
            height: `${particle.size}px`
          }}
          animate={{
            y: [0, -30, 0],
            x: [0, 15, -15, 0],
            opacity: [0.2, 0.5, 0.2]
          }}
          transition={{
            duration: particle.duration,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
        />
      ))}
    </div>
  );
};

// Header Component
const Header = ({ darkMode, setDarkMode, mobileMenuOpen, setMobileMenuOpen }) => {
  return (
    <motion.header 
      className="fixed top-0 left-0 right-0 z-50 bg-card/80 backdrop-blur-lg border-b border-border"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <motion.div 
            className="flex items-center space-x-3"
            whileHover={{ scale: 1.05 }}
          >
            <div className="relative">
              <div className="w-10 h-10 rounded-full gradient-primary flex items-center justify-center glow-effect">
                <Key className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-pulse" />
            </div>
            <h1 className="text-xl font-bold gradient-text">Unlock Books</h1>
          </motion.div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {['Home', 'Encrypt', 'Decrypt', 'API', 'Dashboard', 'About'].map((item) => (
              <motion.a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="text-muted-foreground hover:text-foreground transition-colors relative group"
                whileHover={{ y: -2 }}
              >
                {item}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full" />
              </motion.a>
            ))}
          </nav>

          {/* Controls */}
          <div className="flex items-center space-x-4">
            <Switch
              checked={darkMode}
              onCheckedChange={setDarkMode}
              className="hidden md:flex"
            />
            <Button variant="outline" className="hidden md:flex">
              <Users className="w-4 h-4 mr-2" />
              Login
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              className="md:hidden mt-4 pb-4"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <nav className="flex flex-col space-y-4">
                {['Home', 'Encrypt', 'Decrypt', 'API', 'Dashboard', 'About'].map((item) => (
                  <a
                    key={item}
                    href={`#${item.toLowerCase()}`}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item}
                  </a>
                ))}
                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <span className="text-sm text-muted-foreground">Dark Mode</span>
                  <Switch checked={darkMode} onCheckedChange={setDarkMode} />
                </div>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.header>
  );
};

// Hero Section Component
const HeroSection = () => {
  const [currentAlgorithm, setCurrentAlgorithm] = useState(0);
  const algorithms = ['AES-256', 'RSA-4096', 'ChaCha20', 'Blowfish', 'Twofish'];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentAlgorithm((prev) => (prev + 1) % algorithms.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center matrix-bg overflow-hidden">
      <MatrixRain />
      <FloatingParticles />
      
      <div className="container mx-auto px-4 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.h1 
            className="text-responsive-xl font-bold mb-6 gradient-text"
            animate={{ scale: [1, 1.02, 1] }}
            transition={{ duration: 4, repeat: Infinity }}
          >
            Unlock Any Code – Instantly
          </motion.h1>
          
          <motion.p 
            className="text-responsive-lg text-muted-foreground mb-8 max-w-3xl mx-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            Advanced encryption and decryption with{' '}
            <motion.span 
              className="text-primary font-semibold"
              key={currentAlgorithm}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              {algorithms[currentAlgorithm]}
            </motion.span>
            {' '}and 50+ algorithms
          </motion.p>

          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
          >
            <Button size="lg" className="gradient-primary hover-lift pulse-glow">
              <Lock className="w-5 h-5 mr-2" />
              Start Encrypting
            </Button>
            <Button size="lg" variant="outline" className="hover-lift">
              <Unlock className="w-5 h-5 mr-2" />
              Start Decrypting
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 0.8 }}
          >
            {[
              { label: 'Algorithms', value: '50+', icon: Cpu },
              { label: 'Users', value: '10K+', icon: Users },
              { label: 'Files Processed', value: '1M+', icon: FileText },
              { label: 'Uptime', value: '99.9%', icon: Zap }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                className="text-center"
                whileHover={{ scale: 1.05 }}
              >
                <stat.icon className="w-8 h-8 mx-auto mb-2 text-primary" />
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

// Encryption Section Component
const EncryptionSection = () => {
  const [algorithm, setAlgorithm] = useState('aes');
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [encryptionKey, setEncryptionKey] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [mode, setMode] = useState('cbc');
  const [padding, setPadding] = useState('pkcs7');
  const [keySize, setKeySize] = useState([256]);

  const algorithms = [
    { value: 'aes', label: 'AES (Advanced Encryption Standard)', strength: 'Military Grade' },
    { value: 'rsa', label: 'RSA (Rivest-Shamir-Adleman)', strength: 'Public Key' },
    { value: 'chacha20', label: 'ChaCha20', strength: 'Stream Cipher' },
    { value: 'blowfish', label: 'Blowfish', strength: 'Block Cipher' },
    { value: 'twofish', label: 'Twofish', strength: 'AES Finalist' },
    { value: 'serpent', label: 'Serpent', strength: 'AES Finalist' }
  ];

  const handleEncrypt = async () => {
    if (!inputText.trim()) return;
    
    setIsProcessing(true);
    setProgress(0);
    
    // Simulate encryption process
    for (let i = 0; i <= 100; i += 10) {
      setProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // Simulate encrypted output
    const encrypted = btoa(inputText).split('').reverse().join('');
    setOutputText(encrypted);
    setIsProcessing(false);
  };

  return (
    <section id="encrypt" className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-4 gradient-text">Advanced Encryption</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Secure your data with military-grade encryption algorithms and advanced security features
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Panel */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Card className="glass hover-lift">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="w-5 h-5 text-primary" />
                  Encryption Input
                </CardTitle>
                <CardDescription>
                  Configure your encryption settings and input data
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Algorithm Selection */}
                <div>
                  <label className="block text-sm font-medium mb-2">Encryption Algorithm</label>
                  <Select value={algorithm} onValueChange={setAlgorithm}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {algorithms.map((algo) => (
                        <SelectItem key={algo.value} value={algo.value}>
                          <div className="flex items-center justify-between w-full">
                            <span>{algo.label}</span>
                            <Badge variant="secondary" className="ml-2">
                              {algo.strength}
                            </Badge>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Input Text */}
                <div>
                  <label className="block text-sm font-medium mb-2">Input Text</label>
                  <Textarea
                    placeholder="Enter text to encrypt..."
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    className="min-h-32 font-mono"
                  />
                  <div className="mt-2 flex items-center gap-4">
                    <Button variant="outline" size="sm">
                      <Upload className="w-4 h-4 mr-2" />
                      Upload File
                    </Button>
                    <span className="text-sm text-muted-foreground">
                      {inputText.length} characters
                    </span>
                  </div>
                </div>

                {/* Encryption Key */}
                <div>
                  <label className="block text-sm font-medium mb-2">Encryption Key</label>
                  <div className="flex gap-2">
                    <Input
                      type="password"
                      placeholder="Enter encryption key..."
                      value={encryptionKey}
                      onChange={(e) => setEncryptionKey(e.target.value)}
                      className="font-mono"
                    />
                    <Button variant="outline" size="icon">
                      <RotateCcw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Advanced Options */}
                <div>
                  <Button
                    variant="ghost"
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="w-full justify-between"
                  >
                    Advanced Options
                    <ChevronDown className={`w-4 h-4 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
                  </Button>
                  
                  <AnimatePresence>
                    {showAdvanced && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mt-4 space-y-4 p-4 bg-muted/50 rounded-lg"
                      >
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">Mode</label>
                            <Select value={mode} onValueChange={setMode}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="cbc">CBC</SelectItem>
                                <SelectItem value="ecb">ECB</SelectItem>
                                <SelectItem value="cfb">CFB</SelectItem>
                                <SelectItem value="ofb">OFB</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">Padding</label>
                            <Select value={padding} onValueChange={setPadding}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pkcs7">PKCS7</SelectItem>
                                <SelectItem value="zeros">Zeros</SelectItem>
                                <SelectItem value="none">None</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">
                            Key Size: {keySize[0]} bits
                          </label>
                          <Slider
                            value={keySize}
                            onValueChange={setKeySize}
                            max={512}
                            min={128}
                            step={64}
                            className="w-full"
                          />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Encrypt Button */}
                <Button 
                  onClick={handleEncrypt}
                  disabled={!inputText.trim() || isProcessing}
                  className="w-full gradient-primary hover-lift"
                  size="lg"
                >
                  {isProcessing ? (
                    <>
                      <div className="spinner w-4 h-4 mr-2" />
                      Encrypting...
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4 mr-2" />
                      Encrypt Now
                    </>
                  )}
                </Button>

                {isProcessing && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{progress}%</span>
                    </div>
                    <Progress value={progress} className="w-full" />
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Output Panel */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Card className="glass hover-lift">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Shield className="w-5 h-5 text-primary" />
                    Encrypted Output
                  </div>
                  <Button variant="ghost" size="icon">
                    <Copy className="w-4 h-4" />
                  </Button>
                </CardTitle>
                <CardDescription>
                  Your encrypted data and security details
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Output Text */}
                <div>
                  <label className="block text-sm font-medium mb-2">Encrypted Data</label>
                  <div className="bg-muted/50 rounded-lg p-4 min-h-32 font-mono text-sm code-block">
                    {outputText || (
                      <span className="text-muted-foreground">
                        Encrypted output will appear here...
                      </span>
                    )}
                  </div>
                </div>

                {/* Security Details */}
                {outputText && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-4"
                  >
                    <div>
                      <h4 className="font-medium mb-3">Encryption Details</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Algorithm:</span>
                          <span className="font-medium">{algorithm.toUpperCase()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Key Size:</span>
                          <span className="font-medium">{keySize[0]} bits</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Mode:</span>
                          <span className="font-medium">{mode.toUpperCase()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Time:</span>
                          <span className="font-medium">0.023s</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <Globe className="w-4 h-4 mr-2" />
                        Share
                      </Button>
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// Features Section Component
const FeaturesSection = () => {
  const features = [
    {
      icon: Cpu,
      title: 'AI-Powered Detection',
      description: 'Automatically detect encryption types and suggest optimal decryption methods',
      color: 'text-blue-500'
    },
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Process files up to 1GB in seconds with our optimized algorithms',
      color: 'text-yellow-500'
    },
    {
      icon: Shield,
      title: 'Military Grade Security',
      description: 'Bank-level encryption with zero-knowledge architecture',
      color: 'text-green-500'
    },
    {
      icon: Globe,
      title: 'Global CDN',
      description: 'Distributed processing across 50+ global data centers',
      color: 'text-purple-500'
    },
    {
      icon: BarChart3,
      title: 'Real-time Analytics',
      description: 'Monitor encryption performance and security metrics',
      color: 'text-red-500'
    },
    {
      icon: Users,
      title: 'Team Collaboration',
      description: 'Share encrypted data securely with team members',
      color: 'text-cyan-500'
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-4 gradient-text">Advanced Features</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Discover the cutting-edge capabilities that make our platform the most advanced encryption solution
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="glass hover-lift h-full">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className={`p-3 rounded-lg bg-muted/50 ${feature.color}`}>
                      <feature.icon className="w-6 h-6" />
                    </div>
                    <h3 className="font-semibold text-lg">{feature.title}</h3>
                  </div>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Main App Component
function App() {
  const [darkMode, setDarkMode] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header 
        darkMode={darkMode} 
        setDarkMode={setDarkMode}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />
      <main className="pt-20">
        <HeroSection />
        <EncryptionSection />
        <FeaturesSection />
      </main>
    </div>
  );
}

export default App
