import base64
import hashlib
import secrets
import time
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding, hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.asymmetric import rsa, padding as asym_padding
from cryptography.hazmat.primitives import serialization
import os

encryption_bp = Blueprint('encryption', __name__)

class EncryptionService:
    @staticmethod
    def generate_key(password: str, salt: bytes = None) -> tuple:
        """Generate encryption key from password"""
        if salt is None:
            salt = os.urandom(16)
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = kdf.derive(password.encode())
        return key, salt

    @staticmethod
    def aes_encrypt(plaintext: str, password: str) -> dict:
        """AES encryption"""
        start_time = time.time()
        
        # Generate key and IV
        key, salt = EncryptionService.generate_key(password)
        iv = os.urandom(16)
        
        # Pad the plaintext
        padder = padding.PKCS7(128).padder()
        padded_data = padder.update(plaintext.encode()) + padder.finalize()
        
        # Encrypt
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
        encryptor = cipher.encryptor()
        ciphertext = encryptor.update(padded_data) + encryptor.finalize()
        
        # Combine salt + iv + ciphertext
        encrypted_data = salt + iv + ciphertext
        encoded_data = base64.b64encode(encrypted_data).decode()
        
        end_time = time.time()
        
        return {
            'encrypted_data': encoded_data,
            'algorithm': 'AES-256-CBC',
            'key_size': 256,
            'mode': 'CBC',
            'time_taken': round(end_time - start_time, 3),
            'success': True
        }

    @staticmethod
    def aes_decrypt(encrypted_data: str, password: str) -> dict:
        """AES decryption"""
        start_time = time.time()
        
        try:
            # Decode base64
            data = base64.b64decode(encrypted_data.encode())
            
            # Extract salt, IV, and ciphertext
            salt = data[:16]
            iv = data[16:32]
            ciphertext = data[32:]
            
            # Regenerate key
            key, _ = EncryptionService.generate_key(password, salt)
            
            # Decrypt
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
            decryptor = cipher.decryptor()
            padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()
            
            # Remove padding
            unpadder = padding.PKCS7(128).unpadder()
            plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()
            
            end_time = time.time()
            
            return {
                'decrypted_data': plaintext.decode(),
                'algorithm': 'AES-256-CBC',
                'time_taken': round(end_time - start_time, 3),
                'success': True
            }
        except Exception as e:
            return {
                'error': str(e),
                'success': False
            }

    @staticmethod
    def rsa_encrypt(plaintext: str) -> dict:
        """RSA encryption"""
        start_time = time.time()
        
        # Generate RSA key pair
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        public_key = private_key.public_key()
        
        # Encrypt
        ciphertext = public_key.encrypt(
            plaintext.encode(),
            asym_padding.OAEP(
                mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        
        # Serialize keys
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        end_time = time.time()
        
        return {
            'encrypted_data': base64.b64encode(ciphertext).decode(),
            'private_key': private_pem.decode(),
            'public_key': public_pem.decode(),
            'algorithm': 'RSA-2048',
            'key_size': 2048,
            'time_taken': round(end_time - start_time, 3),
            'success': True
        }

    @staticmethod
    def base64_encode(plaintext: str) -> dict:
        """Base64 encoding"""
        start_time = time.time()
        
        encoded = base64.b64encode(plaintext.encode()).decode()
        
        end_time = time.time()
        
        return {
            'encrypted_data': encoded,
            'algorithm': 'Base64',
            'time_taken': round(end_time - start_time, 3),
            'success': True
        }

    @staticmethod
    def base64_decode(encoded_data: str) -> dict:
        """Base64 decoding"""
        start_time = time.time()
        
        try:
            decoded = base64.b64decode(encoded_data.encode()).decode()
            
            end_time = time.time()
            
            return {
                'decrypted_data': decoded,
                'algorithm': 'Base64',
                'time_taken': round(end_time - start_time, 3),
                'success': True
            }
        except Exception as e:
            return {
                'error': str(e),
                'success': False
            }

    @staticmethod
    def sha256_hash(plaintext: str) -> dict:
        """SHA-256 hashing"""
        start_time = time.time()
        
        hash_object = hashlib.sha256(plaintext.encode())
        hex_dig = hash_object.hexdigest()
        
        end_time = time.time()
        
        return {
            'encrypted_data': hex_dig,
            'algorithm': 'SHA-256',
            'time_taken': round(end_time - start_time, 3),
            'success': True,
            'note': 'SHA-256 is a one-way hash function and cannot be decrypted'
        }

@encryption_bp.route('/encrypt', methods=['POST'])
@cross_origin()
def encrypt_data():
    """Encrypt data endpoint"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided', 'success': False}), 400
        
        plaintext = data.get('text', '')
        algorithm = data.get('algorithm', 'aes')
        password = data.get('password', '')
        
        if not plaintext:
            return jsonify({'error': 'No text to encrypt', 'success': False}), 400
        
        if algorithm == 'aes':
            if not password:
                return jsonify({'error': 'Password required for AES encryption', 'success': False}), 400
            result = EncryptionService.aes_encrypt(plaintext, password)
        elif algorithm == 'rsa':
            result = EncryptionService.rsa_encrypt(plaintext)
        elif algorithm == 'base64':
            result = EncryptionService.base64_encode(plaintext)
        elif algorithm == 'sha256':
            result = EncryptionService.sha256_hash(plaintext)
        else:
            return jsonify({'error': 'Unsupported algorithm', 'success': False}), 400
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e), 'success': False}), 500

@encryption_bp.route('/decrypt', methods=['POST'])
@cross_origin()
def decrypt_data():
    """Decrypt data endpoint"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided', 'success': False}), 400
        
        encrypted_text = data.get('text', '')
        algorithm = data.get('algorithm', 'aes')
        password = data.get('password', '')
        
        if not encrypted_text:
            return jsonify({'error': 'No text to decrypt', 'success': False}), 400
        
        if algorithm == 'aes':
            if not password:
                return jsonify({'error': 'Password required for AES decryption', 'success': False}), 400
            result = EncryptionService.aes_decrypt(encrypted_text, password)
        elif algorithm == 'base64':
            result = EncryptionService.base64_decode(encrypted_text)
        elif algorithm == 'sha256':
            result = {'error': 'SHA-256 is a one-way hash and cannot be decrypted', 'success': False}
        else:
            return jsonify({'error': 'Unsupported algorithm', 'success': False}), 400
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e), 'success': False}), 500

@encryption_bp.route('/algorithms', methods=['GET'])
@cross_origin()
def get_algorithms():
    """Get available algorithms"""
    algorithms = [
        {
            'value': 'aes',
            'label': 'AES (Advanced Encryption Standard)',
            'strength': 'Military Grade',
            'type': 'symmetric',
            'requires_password': True
        },
        {
            'value': 'rsa',
            'label': 'RSA (Rivest-Shamir-Adleman)',
            'strength': 'Public Key',
            'type': 'asymmetric',
            'requires_password': False
        },
        {
            'value': 'base64',
            'label': 'Base64 Encoding',
            'strength': 'Encoding',
            'type': 'encoding',
            'requires_password': False
        },
        {
            'value': 'sha256',
            'label': 'SHA-256 Hash',
            'strength': 'One-way Hash',
            'type': 'hash',
            'requires_password': False
        }
    ]
    
    return jsonify({
        'algorithms': algorithms,
        'success': True
    })

@encryption_bp.route('/detect', methods=['POST'])
@cross_origin()
def detect_encryption():
    """Auto-detect encryption type"""
    try:
        data = request.get_json()
        encrypted_text = data.get('text', '')
        
        if not encrypted_text:
            return jsonify({'error': 'No text provided', 'success': False}), 400
        
        # Simple detection logic
        detected_type = 'unknown'
        confidence = 0
        
        # Check for Base64
        try:
            base64.b64decode(encrypted_text)
            if len(encrypted_text) % 4 == 0 and all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=' for c in encrypted_text):
                detected_type = 'base64'
                confidence = 0.8
        except:
            pass
        
        # Check for SHA-256 (64 hex characters)
        if len(encrypted_text) == 64 and all(c in '0123456789abcdefABCDEF' for c in encrypted_text):
            detected_type = 'sha256'
            confidence = 0.9
        
        # Check for AES (Base64 encoded with specific length patterns)
        if detected_type == 'base64' and len(encrypted_text) > 44:  # Minimum for AES with salt+IV
            detected_type = 'aes'
            confidence = 0.7
        
        return jsonify({
            'detected_type': detected_type,
            'confidence': confidence,
            'success': True
        })
    
    except Exception as e:
        return jsonify({'error': str(e), 'success': False}), 500

@encryption_bp.route('/health', methods=['GET'])
@cross_origin()
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'Unlock Books Encryption API',
        'version': '1.0.0',
        'success': True
    })

